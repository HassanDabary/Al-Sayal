<?php
   session_start();
   include 'DBConnect.php';


   
   $username  = $_GET['username'];
   $password  = $_GET['password'];
   

   $query = "SELECT * from admin where NAME LIKE '$username' and PASSWORD LIKE '$password'";
   
   
 

   if ($stmt = $con->prepare($query)) {
  // Bind parameters (s = string, i = int, b = blob, etc), in our case the username is a string so we use "s"
 
  $stmt->execute();
  // Store the result so we can check if the account exists in the database.
  $stmt->store_result();
  if ($stmt->num_rows > 0) {
  
  $stmt->fetch();
  session_regenerate_id();
    $_SESSION['loggedin'] = TRUE;
    $_SESSION['name'] = $username;
    
    if($username){
      echo 'Done';
    }else{
echo 'Incorrect data!';
    }
    
} else {
  echo 'Incorrect data!';
}
$stmt->close();
}
    
   

   
?>