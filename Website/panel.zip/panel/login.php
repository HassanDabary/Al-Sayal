<?php
// We need to use sessions, so you should always start sessions using the below code.
session_start();
// If the user is not logged in redirect to the login page...
/*if (isset($_SESSION['loggedin'])) {
  header('Location: index.php');
}else{
  
}*/
?>
<!DOCTYPE html>
<html>
<head>
  <title>Login</title>

  <meta charset="UTF-8">
  <meta name="description" content="Free Web tutorials">
  <meta name="keywords" content="HTML,CSS,XML,JavaScript">
  <meta name="author" content="John Doe">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='sukar/Sukar_Black/font.css' rel='stylesheet' type='text/css' />
    <link href='sukar/Sukar_Bold/font.css' rel='stylesheet' type='text/css' />
    <link href='sukar/Sukar_Regular/font.css' rel='stylesheet' type='text/css' />
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
    <link rel="icon"  href="img/logo.png">
      <!-- css -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link href="css/animate.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet">

  <!-- template skin -->
  <link id="t-colors" href="color/default.css" rel="stylesheet">

    
    <style type="text/css">

    </style>
   
    
     <script src="js/index.js">
       
     </script>
     <script >
         function login(){
    document.getElementById("errorLabel").style.display = "none";
    document.getElementById("loadingImg").style.display = "block";
    if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        var username = $("#unameIn").val();
        var password = $("#passwordIn").val();

        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {

                var result = this.responseText;
                if(result == "Done"){
                
                  document.getElementById("loadingImg").style.display = "none";
                  window.open('index.php','_self',false);

                }else{
                  document.getElementById("loadingImg").style.display = "none";
                  document.getElementById("errorLabel").style.display = "block";

                }
               
            }
        };
        xmlhttp.open("GET", "login_back.php?username="+username+"&password="+password, true);
        xmlhttp.send();

      }

     </script>
</head>
<body>


    <!-- header and top navigation -->

      <nav class="navbar navbar-custom" role="navigation">
      <div class="container navigation">

        <div class="navbar-header page-scroll">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>
          <a class="navbar-brand" href="index.html">
                    <img src="img/logo.png" alt="" width="150" height="100" />
                </a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
          <ul class="nav navbar-nav">
            <li>
              <div id="cart"></div>
            </li>
     
            <img src="img/title.png" alt="" width="300" height="100" />

          </ul>
        </div>
        <!-- /.navbar-collapse -->

      </div>
      <!-- /.container -->
    </nav>





    <!-- main body -->
    <div class="container" id="maincont">
       
      <!-- top navigation -->
      

      <style type="text/css">

        .form-control{
          margin-top: 20px;
          height: 50px;
          text-align: left;
          border: 1px solid #790B0A;
          font-family: Sukar_Bold;
          font-size: 20px;
        }

        .saveDriver{
          border-radius: 20px;
          background-color: #3896f9;
          height: 50px;
          width: 50%;
          text-align: center;
          color: #fff;
          cursor: pointer;
          margin-top: 70px;
          margin-left: 25%;
          border:0;
          margin-bottom: 60px;
        }
        h2{
          color: #3896f9;
        }

        .dngr{
          margin-top: 30px;
          margin-left: 120px;
          color: red;
          display: none;
        }

      </style>

    



        <!-- the main content -->
        <div class="row" style="margin-top: 130px">

          <div class="col-md-3"></div>
          <div class="col-md-6" >
            <h4 align="center" style="margin-bottom: 80px;"> تسجيل الدخول </h4>

            
              <input style="text-align: right;" class="form-control"  type="text" id="unameIn" placeholder="... إسم المستخدم">
              <input style="text-align: right;" class="form-control" type="password" id="passwordIn" placeholder=" ...كلمة المرور ">
              <label class="dngr" id="errorLabel">المعلومات غير صحيحة الرجاء المحاولة  مرة أخرى  </label>
              <img style="margin-left: 230px;margin-top: 30px;display: none;" id="loadingImg" align="center" src="img/loading.gif" width="100" height="100" />
              <button class="form-control saveDriver"  onclick="login()" name="registerDriver" > تسجيل الدخول </button>
              
           


          </div>
          <div class="col-md-3"></div>





        </div>















    </div>









  <script src="https://code.jquery.com/jquery-3.4.1.js"
        integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
        crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>

     <!-- Core JavaScript Files -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/jquery.scrollTo.js"></script>
  <!-- If you enabled Analytics in your project, add the Firebase SDK for Analytics -->

  <!-- Add Firebase products that you want to use -->


    <!-- the firebase setup part-->
   
   <script src="https://www.gstatic.com/firebasejs/7.1.0/firebase-app.js"></script>
    <script src="https://www.gstatic.com/firebasejs/7.1.0/firebase-firestore.js"></script>
    <script src="https://www.gstatic.com/firebasejs/7.1.0/firebase-storage.js"></script>

    <script src="https://www.gstatic.com/firebasejs/7.2.1/firebase-analytics.js"></script>
    <script src="https://www.gstatic.com/firebasejs/7.1.0/firebase-auth.js"></script>

 
    <script>
      // Initialize Firebase
  
    </script>

</body>

</html>