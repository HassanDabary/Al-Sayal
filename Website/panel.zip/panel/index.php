<?php
  session_start();
  include 'DBConnect.php';
  // If the user is not logged in redirect to the login page...
  if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit();
  }
?>
<!DOCTYPE html>
<html>
<head>
  <title>Home</title>

  <meta charset="UTF-8">
  <meta name="description" content="Free Web tutorials">
  <meta name="keywords" content="HTML,CSS,XML,JavaScript">
  <meta name="author" content="John Doe">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link href='sukar/Sukar_Black/font.css' rel='stylesheet' type='text/css' />
    <link href='sukar/Sukar_Bold/font.css' rel='stylesheet' type='text/css' />
    <link href='sukar/Sukar_Regular/font.css' rel='stylesheet' type='text/css' />
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
    <link rel="icon"  href="images/logo.png">
      <!-- css -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link href="css/animate.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet">

  <!-- template skin -->
  <link id="t-colors" href="color/default.css" rel="stylesheet">

    <script src="js/jquery.sticky.js"></script>
    
    <style type="text/css">
  <?php
    /*if($_SESSION['name'] != 'mohammed'){
      echo "#addperm,#discountperm,#promoperm,#rowperm{display:none;}";
    }*/
    ?>
    </style>
    
    
   
</head>
<body>


    <!-- header and top navigation -->

     
       <nav class="navbar navbar-custom" role="navigation">
      <div class="container-fluid navigation">

        <div class="navbar-header page-scroll">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>
          <a class="navbar-brand" href="index.html">
                    <img src="img/logo.png" alt="" width="150" height="80" />
                </a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse navbar-right navbar-main-collapse" style="margin-top: 20px;">
          <ul class="nav navbar-nav">
            <li>
              <div id="cart"></div>
            </li>
             <li ><a href="logout.php" style="color:red">تسجيل الخروج</a> </li>
               <li><a href="addvideo.php"> تعديل الفيديو </a></li>
           <li><a href="editcontacts.php"> تعديل بيانات التواصل </a></li>
              <li id="discountperm" ><a href="editimage.php"> تعديل  محتوى  الصورة </a></li>
             <li><a href="addimage.php"> اضافة صورة  </a></li>
             <li  ><a href="editpost.php"> تعديل المنشور  </a></li>
             <li ><a href="addpost.php"> إضافة منشور  </a></li>
             <li ><a href="addproj.php"> اضافة مشروع </a></li>
             <li class="active" ><a href="index.php">الرئيسية </a></li>
            

          </ul>
        </div>
        <!-- /.navbar-collapse -->

      </div>
      <!-- /.container -->
    </nav>

<!--
<?php
/*if($_SESSION['name'] == 'mohammed'){
  echo "<style>.addpermission{display:block;} </style>";
}*/
?>
-->

    <!-- main body -->
    <div class="container" id="maincont">
       
      <!-- top navigation -->
      

      <style type="text/css">
        body{
        background-image: url("img/back.jpg") ;
        background-repeat: no-repeat;
        background-size: 100% ;
      }
         .container {
              width: 960px !important;

          }
          .container-fluid {
              width: 1260px !important;
          }

          @media (min-width: 1px) {
            .container {
              max-width: 940px;
            }
        
        .form-control{
          margin-top: 20px;
          height: 50px;
          text-align: left;
          border: 1px solid #790B0A;
          font-family: Sukar_Bold;
          font-size: 20px;
        }

        .saveDriver{
          border-radius: 20px;
          background-color: #1e3956;
          height: 50px;
          width: 50%;
          text-align: center;
          color: #fff;
          cursor: pointer;
          margin-top: 70px;
          margin-left: 25%;
          border:0;
          margin-bottom: 60px;
        }
        h2{
          color: #790B0A;
        }
        button{
          width: 100%;
          height: 200px;
          margin: 10px;
          font-size: 26px;
          font-family: Sukar_Bold;
          color: #fff;
          border:0px;
        }
       button:hover{
        opacity: 0.3;
       }
       .addpermission{
        display: none;
       }
      </style>
 
    


        <div class="row" style="margin-top: 10px">
          <div class="col-md-4"></div>
          <div class="col-md-4">
            
             <h4 style="font-family: Sukar_Bold" align="center">الرئيسية</h4>
           
          </div>
          <div class="col-md-4"></div>
         
        </div>
        <!-- the main content -->
        <div class="row" style="margin-top: 20px">

          <div class="col-md-2"></div>
          <div class="col-md-8" >
            <div class="row">

              <div class="col-md-6">
                <a href="editpost.php"> <button style="background-color: #21618c ;"> تعديل المنشور  </button></a>
              </div>
              <div class="col-md-6">
                
               
                <a href="addpost.php"><button style="background-color: #21618c ;"> إضافة  منشور  </button></a>
              </div>
              
            </div> 
           
            <div class="row" id="rowperm" >
                <div class="col-md-6">
               <a href="editimage.php"> <button style="background-color: #21618c ;"> تعديل محتوى الصورة </button></a>
              </div>
              <div class="col-md-6">
               <a href="addimage.php"> <button style="background-color: #e59866 ;"> إضافة  صورة  </button></a>
              </div>
            
              
            </div>
            <div class="row" id="rowperm" >
               
              <div class="col-md-6">
               <a href="addvideo.php"> <button style="background-color: #e59866 ;"> تعديل الفيديو </button></a>
              </div> 
               <div class="col-md-6">
               <a href="editcontacts.php"> <button style="background-color: #e59866 ;"> تعديل بيانات التواصل  </button></a>
              </div>
              <div class="col-md-6">
               <a href="addproj.php"> <button style="background-color: #e59866 ;">اضافة مشروع</button></a>
              </div>
              <div class="col-md-6">
               <a href="addleader.php"> <button style="background-color: #e59866 ;">اضافة قائد</button></a>
              </div>
              <div class="col-md-6">
               <a href="historical.php"> <button style="background-color: #e59866 ;">تعديل البيانات التاريخية</button></a>
              </div>
            
            
              
            </div>
            
          </div>
          <div class="col-md-2"></div>

        </div>

    </div>









  

    <script src="js/jquery.min.js" type="text/javascript"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
     <!-- Core JavaScript Files -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/jquery.scrollTo.js"></script>

   
      <!-- the firebase setup part-->
      <script src="https://www.gstatic.com/firebasejs/7.1.0/firebase-app.js"></script>
    <script src="https://www.gstatic.com/firebasejs/7.1.0/firebase-firestore.js"></script>
    <script src="https://www.gstatic.com/firebasejs/7.1.0/firebase-storage.js"></script>

    <script src="https://www.gstatic.com/firebasejs/7.2.1/firebase-analytics.js"></script>
    <script src="https://www.gstatic.com/firebasejs/7.1.0/firebase-auth.js"></script>
 
    <script>
      // Initialize Firebase
     
 
    </script>
    <script src="js/index.js"></script>
</body>

</html>