<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'sayal';

$con = mysqli_connect($host,$user,$pass,$db) or die("Could Not Connect to the database");
$sSQL= 'SET CHARACTER SET utf8'; 

mysqli_query($con,$sSQL) 

?>