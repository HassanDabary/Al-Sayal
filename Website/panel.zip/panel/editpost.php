<?php
// We need to use sessions, so you should always start sessions using the below code.
session_start();
// If the user is not logged in redirect to the login page...
if (!isset($_SESSION['loggedin'])) {
  header('Location: login.php');
  exit();
}

?>

<!DOCTYPE html>
<html>
<head>
  <title>Posts</title>

  <meta charset="UTF-8">
  <meta name="description" content="Free Web tutorials">
  <meta name="keywords" content="HTML,CSS,XML,JavaScript">
  <meta name="author" content="John Doe">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link href='sukar/Sukar_Black/font.css' rel='stylesheet' type='text/css' />
    <link href='sukar/Sukar_Bold/font.css' rel='stylesheet' type='text/css' />
    <link href='sukar/Sukar_Regular/font.css' rel='stylesheet' type='text/css' />
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
    <link rel="icon"  href="img/logo.png">
      <!-- css -->
      <script src="https://code.jquery.com/jquery-3.4.1.js"
        integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
        crossorigin="anonymous"></script>
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link href="css/animate.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet">
       <script src="js/bootstrap.min.js" type="text/javascript"></script>
     <!-- Core JavaScript Files -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/jquery.scrollTo.js"></script>

     <link href = "https://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css"
       rel = "stylesheet">
    <script src = "https://code.jquery.com/jquery-1.10.2.js"></script>
    <script src = "https://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
    
    
    <script src="js/index.js"></script>


  <!-- template skin -->
  <link id="t-colors" href="color/default.css" rel="stylesheet">

    <style type="text/css">
   
    </style>
     <!-- Javascript -->

    <!-- Javascript -->
      <script>
         $(function() {
          document.getElementById("loading").style.display = "none";
          
            $( "#pSearch" ).autocomplete({
               source: <?php echo $resul;?>,
               autoFocus:true
            });
         });

      </script>
    
    <script type="text/javascript">
  function add_product(){
         
        document.getElementById("loading").style.display = "block";
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        var amount = $("#pAmount").val();
        var b_price = $("#pPrice").val();
        var product = $("#pSearch").val();

        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
              var result = this.responseText;
              if (result == "Done") {
                Swal.fire(
                  'تمت إضافة الإسبير بنجاح ',
                  '',
                  'success'
                );
                document.getElementById("loading").style.display = "none";
                document.getElementById("pAmount").value = "";
                document.getElementById("pPrice").value = "";
                document.getElementById("pSearch").value = "";
              }else{
                alert(result);
              }

                
                
                


              
            }
        };
        xmlhttp.open("GET", "add_product.php?product="+product+"&base_price="+b_price+"&available_amount="+amount, true);
        xmlhttp.send();


      }
    </script>
   
</head>
<body>


    <!-- header and top navigation -->

      <nav class="navbar navbar-custom" role="navigation">
      <div class="container-fluid navigation">

        <div class="navbar-header page-scroll">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>
          <a class="navbar-brand" href="index.html">
                    <img src="img/logo.png" alt="" width="150" height="80" />
                </a>
        </div>

        <!-- Collect the nav links, forms, and o
          ther content for toggling -->
        <div class="collapse navbar-collapse navbar-right navbar-main-collapse" style="margin-top: 20px;">
          <ul class="nav navbar-nav">
            <li>
              <div id="cart"></div>
            </li>
             <li ><a href="logout.php" style="color:red">تسجيل الخروج</a> </li>
               <li><a href="addvideo.php"> تعديل الفيديو </a></li>
           <li><a href="editcontacts.php"> تعديل بيانات التواصل </a></li>
              <li id="discountperm"><a href="editimage.php"> تعديل  محتوى  الصورة </a></li>
             <li><a href="addimage.php"> اضافة صورة  </a></li>
             <li class="active"><a href="editpost.php"> تعديل المنشور  </a></li>
             <li ><a href="addpost.php"> إضافة منشور  </a></li>
             <li ><a href="addproj.php"> اضافة مشروع </a></li>
             <li ><a href="index.php">الرئيسية </a></li>
            

          </ul>
        </div>
        <!-- /.navbar-collapse -->

      </div>
      <!-- /.container -->
    </nav>





    <!-- main body -->
    <div class="container-fluid" id="maincont">

      <!-- top navigation -->
      

      <style type="text/css">
        .container {
              width: 960px !important;
          }
          .container-fluid {
              width: 1260px !important;
          }

          @media (min-width: 1px) {
            .container {
              max-width: 940px;
            }

        .col-md-1,
        .col-md-2,
        .col-md-3,
        .col-md-4,
        .col-md-5,
        .col-md-6,
        .col-md-8,
        .col-md-10,
        .col-md-12 {
          float: left;
        }
        .col-md-1 {
          width: 8.333333333333332%;
        }
        .col-md-2 {
          width: 16.666666666666664%;
        }
        .col-md-3 {
          width: 25%;
        }
        .col-md-4 {
          width: 33.33333333333333%;
        }
        .col-md-5 {
          width: 41.66666666666667%;
        }
        .col-md-6 {
          width: 50%;
        }
        .col-md-7 {
          width: 58.333333333333336%;
        }
        .col-md-8 {
           width: 66.66666666666666%;
        }
        .col-md-10 {
          width: 83.33333333333334%;
        }
        .col-md-12 {
          width: 100%;
        }
        
        .form-control{
          margin-top: 5px;
          
          text-align: left;
          border: 1px solid blue;
          font-family: Sukar_Bold;
         
        }

        .saveDriver{
          border-radius: 20px;
          background-color: #3896f9;
          
          width: 70%;
          text-align: center;
          color: #fff;
          cursor: pointer;
  
          border:0;
        } 
         .openUser{
          border-radius: 20px;
          background-color: #790B0A;
          
          width: 70%;
          text-align: center;
          color: #fff;
          cursor: pointer;
  
          border:0;
        }

        h2{
          color: #1e3956;
        }
        label{
          font-family: Sukar_Bold;
        }
        #resultTitle{
          display: none;
        }
        #resultDiv{
          display: none;
        }
        #resultPay{
          display: none;
        }
        .dngr{
          margin-top: 30px;
          margin-left: 190px;
          color: red;
          display: none;
        }
         .addpermission{
        display: none;
       }
      
      </style>
 
    


        <!-- the main content -->
        <div class="row" style="margin-top: 10px">
       
          


          <div class="col-md-12" >
            <div class="row" align="center">
              <div class="col-md-4"></div>
              <div class="col-md-4">
                <h2> تعديل المنشور </h2>
              </div>
              <div class="col-md-4"></div>
            </div>
       
         
        <!---->
           <div class="row">
             <div class="col-md-3"></div>
              <div class="col-md-6">
               <input class="form-control" style="text-align: right" dir="rtl"  type="text" id="pAmount" placeholder="عنوان المنشور ...">
             </div>
              <div class="col-md-3"></div>
            
           </div>
           
         <!---->
           <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
               <textarea class="form-control" style="text-align: right" dir="rtl" type="text" id="pSearch" placeholder="محتوى المنشور ..."></textarea>
             </div>
              <div class="col-md-3"></div>
           </div>

          <!---->
          <div class="row">
             <div class="col-md-3"></div>
             <div class="col-md-6">
               <input class="form-control" style="text-align: right" dir="rtl"  type="file" id="pPrice" placeholder=" إضافة صورة...">
             </div>
           <div class="col-md-3"></div>
             
           </div>


         <div class="container">
           <div id="loading" align="center" style="margin-bottom: 30px;display: none">
             <img align="center" src="img/loading.gif" width="50" height="50">
           </div>
        
           <div class="row" id="resultTitle">
              <h4 align="center" >Result</h4>
           </div>

           

             <hr>

             <script type="text/javascript">
                 var counter = 0;
                 var colo = "style='background-color: gray'";
                 function addRow() {
                  var x = counter % 2;
                   if( x== 0){
                   var colo = "style='padding-left: 20px; padding-right: 20px;'";
                   }else{
                    var colo = "style='padding-left: 20px; padding-right: 20px;background-color: #F2F8FD'";
                   }
                   counter ++;
                   var dr = "<div class='row' id='restultOne'  "+colo+">"+
                          
                       "<div class='col-md-2' >"+
                          "<div align='right' class='row' style='padding-top: 5px;' >"+
                             "<label>"+document.getElementById("pDiscount").value+"</label>"+
                          "</div>"+
                       "</div>"+
                       "<div class='col-md-2' >"+
                          "<div align='right' class='row' style='padding-top: 5px;' >"+
                             "<label>"+document.getElementById("pPrice").value+"</label>"+
                          "</div>"+
                       "</div>"+
                       "<div class='col-md-2' >"+
                          "<div align='right' class='row' style='padding-top: 5px;' >"+
                             "<label>"+document.getElementById("pAmount").value+"</label>"+
                          "</div>"+
                       "</div>"+
                       "<div class='col-md-3' >"+
                          "<div align='right' class='row' style='padding-top: 5px;' >"+
                             "<label>"+document.getElementById("pSearch").value+"</label>"+
                          "</div>"+
                       "</div>"+
                       "<div class='col-md-3' >"+
                          "<div align='right' class='row' style='padding-top: 5px;' >"+
                             "<label>"+document.getElementById("pSearch").value+"</label>"+
                          "</div>"+
                       "</div>"+
                     "</div><hr>";
                   document.getElementById("resultDivi").innerHTML += dr;
                 }

               
             </script>
             <div id="resultDivi"></div>

          <br>
          <div class="row" align="center" style="margin-bottom: 50px">
            <div class="col-md-3"></div>
            <div class="col-md-6">
               <button class="form-control saveDriver"  onclick="srearchUser()" name="searchDriver" > إضافة منشور جديد </button>
             </div>

            <div class="col-md-3"></div>
          </div>
         
          
          </div>
          </div>

         
        




        </div>














    </div>









  
 

    

 
    <script>
      // Initialize Firebase
   
    </script>
</body>

</html>