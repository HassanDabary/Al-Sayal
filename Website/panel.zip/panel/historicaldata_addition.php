<?php
   include 'DBConnect.php';

   $post_body  = $_GET['body'];
   $post_image  = $_GET['image'];

   if($post_title){
     $inser_quer = "INSERT INTO `post`(`id`, `content`, `image`) VALUES ('',N,'$post_body','$post_image')";
      $qry_resu = mysqli_query($con,$inser_quer) or die(mysqli_error($con));
      echo "Done";
   
   }

   
?>