<?php
   include 'DBConnect.php';

   $post_title  = $_GET['title'];
   $post_body  = $_GET['body'];
   $post_image  = $_GET['image'];
   $is_video  = $_GET['isvideo'];
   $date = new DateTime("now", new DateTimeZone('Africa/Cairo') );
  $tm = new DateTime("now", new DateTimeZone('Africa/Cairo') );
  //$date = $date->format('Y-m-d');
       $time = $tm->format('H:i:s');

   if($post_title){
     $inser_quer = "INSERT INTO `post`(`ID`, `TITLE`, `BODY`, `IMAGE`, `ISVIDEO`, `DATE`) VALUES ('',N'$post_title','$post_body','$post_image','$is_video',$date)";
      $qry_resu = mysqli_query($con,$inser_quer) or die(mysqli_error($con));
      echo "Done";
   
   }

   
?>